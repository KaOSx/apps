#! /usr/bin/env bash
$XGETTEXT `find . -name \*.qml` -o $podir/plasma_wallpaper_org.kde.plasma.%{APPNAMELC}.pot
