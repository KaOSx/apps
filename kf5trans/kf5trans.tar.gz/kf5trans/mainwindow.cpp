/*
 * Copyright (c) 2015       Anke Boersma <demm@kaosx.us>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 */

#include <QtGui>
#include <QMessageBox>
#include <QProcess>
#include <QDesktopWidget>
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QRect position = frameGeometry();
      position.moveCenter(QDesktopWidget().availableGeometry().center());
      move(position.topLeft());

    Qt::WindowFlags flags;
    flags = Qt::Window
            | Qt::WindowMinimizeButtonHint
            | Qt::WindowCloseButtonHint;
        setFixedSize(550,400);
    setWindowFlags( flags );

    // signals/slots mechanism in action
    this->connect(this->ui->pushButton_reboot, SIGNAL(clicked()), this, SLOT(RebootKaOS()));
    this->connect(this->ui->pushButton_poweroff, SIGNAL(clicked()), this, SLOT(PoweroffKaOS()));
}


void MainWindow::RebootKaOS()
{
    QProcess::startDetached("xterm -e sudo systemctl reboot");
}


void MainWindow::PoweroffKaOS()
{
    QProcess::startDetached("xterm -e sudo systemctl poweroff");
}


